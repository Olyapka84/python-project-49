### Hexlet tests and linter status:
[![Actions Status](https://github.com/Olyapka84/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Olyapka84/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/f0618576d8712cb54dbc/maintainability)](https://codeclimate.com/github/Olyapka84/python-project-49/maintainability)

## Even game demonstration:

[![asciicast](https://asciinema.org/connect/8e81ff5f-66a1-410e-9035-4f8b4d61b1b3)](https://asciinema.org/connect/8e81ff5f-66a1-410e-9035-4f8b4d61b1b3)

## Calc game demonstration:

[![asciicast](https://asciinema.org/a/ev85LFANXyhH07lDQ5FytGkzr)](https://asciinema.org/a/ev85LFANXyhH07lDQ5FytGkzr)

## GCD game demonstration:

[![asciicast](https://asciinema.org/a/xy9wtvhmgF6DeDEYibP7AVU9u)](https://asciinema.org/a/xy9wtvhmgF6DeDEYibP7AVU9u)

## Progression game demonstration:

[![asciicast](https://asciinema.org/a/xNA4YK7m2tnYTlvQj1dCvejmL)](https://asciinema.org/a/xNA4YK7m2tnYTlvQj1dCvejmL)
